const express = require("express");
const app = express();
const port = 8080;
const fs = require("fs");

app.use(express.json());

const userData = require("./user.json");

app.listen(port, () => {
  console.log("Ang Imong server nag dagan na sa localhost 8080 sis!");
});

app.get("/getUsers", (req, res) => {
  res.json(userData.users);
});

app.get("/getUsers/:id", (req, res) => {
  const userId = parseInt(req.params.id);
  const user = userData.users.find((u) => u.id === userId);

  if (user) {
    res.json(user);
  } else {
    res.status(404).json({ message: "User Not Found" });
  }
});

app.post("/addUser", (req, res) => {
  const newUser = req.body;
  newUser.id = userData.users.length + 1;
  userData.users.push(newUser);

  fs.writeFileSync("./user.json", JSON.stringify(userData, null, 2), "utf-8");

  res.status(200).json(newUser);
});

app.put("/updateUser/:id", (req, res) => {
  const userId = parseInt(req.params.id);
  const updatedUser = req.body;

  const userIndex = userData.users.findIndex((u) => u.id === userId);

  if (userIndex !== -1) {
    userData.users[userIndex] = { ...userData.users[userIndex], ...updatedUser };
    fs.writeFileSync("./user.json", JSON.stringify(userData, null, 2), "utf-8");
    res.status(200).json(userData.users[userIndex]);
  } else {
    res.status(404).json({ message: "User Not Found" });
  }
});

app.delete("/deleteUser/:id", (req, res) => {
  const userId = parseInt(req.params.id);

  const userIndex = userData.users.findIndex((u) => u.id === userId);

  if (userIndex !== -1) {
    userData.users.splice(userIndex, 1);
    fs.writeFileSync("./user.json", JSON.stringify(userData, null, 2), "utf-8");
    res.status(200).json({ message: "User deleted" });
  } else {
    res.status(404).json({ message: "User Not Found" });
  }
});